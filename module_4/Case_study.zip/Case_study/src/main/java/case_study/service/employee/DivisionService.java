package case_study.service.employee;


import case_study.model.employee.Division;

import java.util.List;

public interface DivisionService {
    List<Division> findAll();
}

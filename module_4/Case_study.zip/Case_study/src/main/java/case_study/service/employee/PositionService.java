package case_study.service.employee;

import case_study.model.employee.Position;

import java.util.List;

public interface PositionService {
    List<Position> findAll();
}

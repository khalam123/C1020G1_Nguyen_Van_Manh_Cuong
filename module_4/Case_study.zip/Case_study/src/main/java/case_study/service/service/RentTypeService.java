package case_study.service.service;

import case_study.model.service.RentType;

import java.util.List;

public interface RentTypeService {
    List<RentType> findAll();
}

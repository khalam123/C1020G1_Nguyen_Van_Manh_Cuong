package case_study.service.contract;

import case_study.model.contract.AttachService;

import java.util.List;

public interface AttachServiceService {
    List<AttachService> findAll();
}

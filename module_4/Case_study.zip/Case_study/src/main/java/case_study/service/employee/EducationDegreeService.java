package case_study.service.employee;


import case_study.model.employee.EducationDegree;

import java.util.List;

public interface EducationDegreeService {
    List<EducationDegree> findAll();
}

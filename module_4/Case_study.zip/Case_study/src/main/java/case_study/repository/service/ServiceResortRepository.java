package case_study.repository.service;


import case_study.model.service.ServiceResort;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ServiceResortRepository extends JpaRepository<ServiceResort,Integer> {

}
